package com.cyberark.items.quality.updater;

import com.cyberark.items.entities.Item;
import com.cyberark.items.quality.category.CategoryTag;
import com.cyberark.items.quality.category.TaggedItem;

public class QualityUpdaterFactory {
    public static QualityUpdater getQualityUpdater(Item item){

        if ("Basketball".equals(item.getName())){
            return new BasketballQualityUpdater(new TaggedItem(item));

        } else if ("Scotch Bottle".equals(item.getName())){
            return new ScotchBottleQualityUpdater(new TaggedItem(item));

        } else if ("Premium Beer".equals(item.getName()) ||
                ("Premium T-Shirt").equals(item.getName())){
            TaggedItem taggedItem = new TaggedItem(item);
            taggedItem.addTag(CategoryTag.premium);
            return new DefaultQualityUpdater(taggedItem);

        } else if ("Premium Basketball".equals(item.getName())){
            TaggedItem taggedItem = new TaggedItem(item);
            taggedItem.addTag(CategoryTag.premium);
            return new BasketballQualityUpdater(taggedItem);

        } else if ("Premium Scotch Bottle".equals(item.getName())){
            TaggedItem taggedItem = new TaggedItem(item);
            taggedItem.addTag(CategoryTag.premium);
            return new ScotchBottleQualityUpdater(taggedItem);

        }

        else {
            return new DefaultQualityUpdater(new TaggedItem(item));
        }
    }
}
