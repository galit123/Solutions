package com.cyberark.items.quality.category;

public interface QualityCategory {
    int getQualityQuantity();
}
