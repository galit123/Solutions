package com.cyberark.items.quality.category;

public enum CategoryTag {
    premium, veganfriendly ;
}
