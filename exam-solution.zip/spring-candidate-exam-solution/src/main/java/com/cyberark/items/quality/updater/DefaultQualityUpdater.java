package com.cyberark.items.quality.updater;

import com.cyberark.items.quality.category.TaggedItem;

public class DefaultQualityUpdater extends QualityUpdater {
    public DefaultQualityUpdater(TaggedItem item) {
        super(item.getItem(), item.getCategoryTags());
    }

    @Override
    public void updateQuality() {
        if (item.getQuality() > 0) {
            item.setQuality(item.getQuality() - getQualityQuantity());
        }
        item.setSellIn(item.getSellIn() - getQualityQuantity());
        if (item.getSellIn() < 0) {
            if (item.getQuality() > 0) {
                item.setQuality(item.getQuality() - getQualityQuantity());
            }
        }
    }
}

