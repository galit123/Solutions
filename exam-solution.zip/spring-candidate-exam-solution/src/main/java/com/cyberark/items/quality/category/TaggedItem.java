package com.cyberark.items.quality.category;

import com.cyberark.items.entities.Item;

import java.util.ArrayList;
import java.util.List;

public class TaggedItem {
    private List<CategoryTag> categoryTags = new ArrayList<CategoryTag>();
    private Item item;

    public Item getItem() {
        return item;
    }

    public TaggedItem(Item item) {
        this.item = item;
    }

    public List<CategoryTag> getCategoryTags() {
        return categoryTags;
    }

    public void addTag(CategoryTag tag){
        categoryTags.add(tag);
    }

    public void removeTag(CategoryTag tag){
        categoryTags.remove(tag);
    }
}
