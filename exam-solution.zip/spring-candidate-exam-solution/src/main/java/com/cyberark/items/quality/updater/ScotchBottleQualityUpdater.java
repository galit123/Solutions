package com.cyberark.items.quality.updater;

import com.cyberark.items.quality.category.TaggedItem;

public class ScotchBottleQualityUpdater extends QualityUpdater {
    public ScotchBottleQualityUpdater(TaggedItem item) {
        super(item.getItem(),item.getCategoryTags());
    }

    @Override
    public void updateQuality() {
        if (item.getQuality() < 50) {
            item.setQuality(item.getQuality() + getQualityQuantity());
        }
        item.setSellIn(item.getSellIn() - getQualityQuantity());

        if (item.getSellIn() < 0) {
            if (item.getQuality() < 50) {
                item.setQuality(item.getQuality() + getQualityQuantity());
            }
        }
    }
}



