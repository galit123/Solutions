package com.cyberark.items;

import com.cyberark.items.entities.Item;
import com.cyberark.items.error.ItemNotFoundException;
import com.cyberark.items.services.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ItemsController {
    @Autowired
    ItemService itemService;

    @GetMapping("api/items")
    public ResponseEntity<List<Item>> findAll(){
        return new ResponseEntity<List<Item>>(itemService.getItems(), HttpStatus.OK);
    }

    @GetMapping("api/items/{id}")
    public ResponseEntity<Item> findById(@PathVariable String id){
        long lid = Long.valueOf(id);
        Item item = itemService.getItem(lid);
        if (item == null){
            throw new ItemNotFoundException(id + " is not found");
        }
        return new ResponseEntity<Item>(itemService.getItem(lid), HttpStatus.OK);
    }

    @PostMapping(path="api/items")
    public ResponseEntity<Item> create(@RequestBody  Item item){
        Item newItem = itemService.createItem(item);
        return new ResponseEntity<Item>(newItem, HttpStatus.CREATED);
    }

}
