package com.cyberark.items.quality.updater;

import com.cyberark.items.quality.category.TaggedItem;

public class BasketballQualityUpdater extends QualityUpdater {
    public BasketballQualityUpdater(TaggedItem item) {
        super(item.getItem(), item.getCategoryTags());
    }

    @Override
    public void updateQuality() {
    }

 }
