package com.cyberark.items.quality.updater;

import com.cyberark.items.entities.Item;
import com.cyberark.items.quality.category.CategoryTag;
import com.cyberark.items.quality.category.QualityCategory;

import java.util.List;

public abstract class QualityUpdater implements QualityCategory {

    protected List<CategoryTag> categories;
    protected Item item;

    public QualityUpdater(Item item, List<CategoryTag> categories) {
        this.item = item;
        this.categories = categories;
    }

    public abstract void updateQuality();

    public int getQualityQuantity(){
        if (categories.contains(CategoryTag.premium)) {
            return 2;
        }

        return 1;
    }
}
