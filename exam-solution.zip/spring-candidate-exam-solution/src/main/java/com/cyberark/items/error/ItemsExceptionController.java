package com.cyberark.items.error;

import com.cyberark.items.entities.Item;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ItemsExceptionController {

    @ExceptionHandler(value = ItemNotFoundException.class)
    public ResponseEntity<Item> exception(ItemNotFoundException exception) {

        return new ResponseEntity<Item>(HttpStatus.NOT_FOUND);
    }

}
